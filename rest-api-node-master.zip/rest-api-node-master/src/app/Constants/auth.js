module.exports = {
  secret: "openSecret",
  rounds: 15
};
