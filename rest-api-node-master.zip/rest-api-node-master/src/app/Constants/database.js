module.exports = {
  databaseUrl:
    "mongodb+srv://renanlopes:opendb8@cluster.mflsx.mongodb.net/projects?retryWrites=true&w=majority",
};
